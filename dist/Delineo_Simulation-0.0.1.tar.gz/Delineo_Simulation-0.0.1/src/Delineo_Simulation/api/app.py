from flask import Flask, request

import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from simulation.master import MasterController
app = Flask(__name__)


@app.route("/")
def home():
    return "<h1>Homepage of Simulation Api</h1>"


@app.route("/simulation", methods=['POST'])
def run_simulation():
    mc = MasterController()
    mc.runFacilityTests('facilities_info.txt')
    return request.get_json()


@app.route("/covid_ui", methods=['POST'])
def run_simulation():
    mc = MasterController()
    mc.runFacilityTests('facilities_info.txt')
    return request.get_json()


app.run(host="", debug=True, port=5000, threaded=True)
